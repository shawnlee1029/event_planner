import 'package:event_planner/event_form_page.dart';
import 'package:event_planner/event_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:event_planner/event_form.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

main() {
  group('Event Form Testing',()
  {
    testWidgets('Adds an event when valid EventForm is submitted',
            (WidgetTester tester) async {
          final eventViewModel = EventViewModel();
          final router = GoRouter(routes: [GoRoute(path: '/',builder: (context, _) =>const EventFormPage())]);
          await tester.pumpWidget(ChangeNotifierProvider.value(
              value: eventViewModel,
              child:  MaterialApp.router(routerConfig: router)));

          await tester.enterText(find
              .byType(TextFormField)
              .first, 'Concert');
          await tester.pump();

          final submitButton = find.text('Add Event');
          await tester.tap(submitButton);
          await tester.pump();

          expect(eventViewModel.eventCount, 1);
        });
  });
}
