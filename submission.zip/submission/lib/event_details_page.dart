import 'package:flutter/material.dart';

import 'event_details_viewer.dart';

class EventDetailsPage extends StatelessWidget {
  final int index;
  const EventDetailsPage({Key? key, required this.index}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(),
      body: EventDetailsViewer(index: index),
    );
  }
}
