import 'package:event_planner/event_view_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DateSelector extends StatefulWidget {
  final int? index;

  const DateSelector({Key? key, this.index}) : super(key: key);

  @override
  State<DateSelector> createState() => _DateSelectorState();
}

class _DateSelectorState extends State<DateSelector> {
  late final DateTimeRange initialDateTimeRange;
  late final eventViewModel = context.read<EventViewModel>();

  @override
  initState() {
    initialDateTimeRange = widget.index != null
        ? eventViewModel.getDateTimeRange(widget.index)
        : DateTimeRange(start: DateTime.now(), end: DateTime.now());
    super.initState();
  }

  _selectDateRange(EventViewModel eventViewModel) async {
    final DateTimeRange? dateRangePicked = await showDateRangePicker(
        context: context,
        initialDateRange: initialDateTimeRange,
        firstDate: DateTime(2023),
        lastDate: DateTime(2123));
    //edit event
    if (dateRangePicked != null && widget.index != null) {
      eventViewModel.editEventDateRange(dateRangePicked, widget.index!);
    }
  }

  //
  // _selectTime(EventViewModel eventViewModel) async {
  //   final TimeOfDay? timeOfDay = await showTimePicker(
  //       context: context, initialTime: initialTime)
  // }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(children: [
      Row(children: [
        Text('Start'),
        Text('End'),
      ]),
    ]));
  }
}
