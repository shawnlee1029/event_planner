import 'package:event_planner/event_details_nav_button.dart';
import 'package:event_planner/event_view_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class EventDetailsViewer extends StatelessWidget {
  final int index;

  const EventDetailsViewer({Key? key, required this.index}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    final eventViewModel = context.read<EventViewModel>();
    return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(eventViewModel.getTitle(index),style: Theme.of(context).textTheme.displayMedium),
        Text(eventViewModel.getDescription(index),style: Theme.of(context).textTheme.displaySmall),
        Text('${eventViewModel.getStartString(index)}${eventViewModel.getEndString(index)}',style: Theme.of(context).textTheme.bodyMedium),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children:  [
              EventDetailsNavButton(index: index, next: false),
              EventDetailsNavButton(index: index, next: true),
          ],)
      ],
    )
    );
  }
}
