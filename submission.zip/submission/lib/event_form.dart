import 'package:event_planner/date_selector.dart';
import 'package:flutter/material.dart';
import 'package:event_planner/event.dart';
import 'package:event_planner/event_view_model.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:event_planner/event_describer.dart';

class EventForm extends StatefulWidget {
  final int? index;

  const EventForm({super.key, this.index});

  @override
  State<EventForm> createState() => _EventFormState();
}

class _EventFormState extends State<EventForm> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController(text: null);
  final _descriptionController = TextEditingController(text: null);

  //DateTime start = DateTime.now();
  //DateTime end = DateTime.now();
  DateTimeRange _dateTimeRange = DateTimeRange(
      start: DateTime.now(), end: DateTime.now().add(const Duration(days: 1)));

  String _dateDisplay(DateTime dateTime) =>
      DateFormat().add_yMd().format(dateTime);

  String _timeDisplay(DateTime dateTime) =>
      DateFormat().add_jm().format(dateTime);

  String _fullDisplay(DateTime dateTime) =>
      DateFormat().add_yMd().add_jm().format(dateTime);
  _selectDateRange() async {
    final DateTimeRange? dateRangePicked = await showDateRangePicker(
        context: context,
        initialDateRange: _dateTimeRange,
        firstDate: DateTime(2023),
        lastDate: DateTime(2123));
    if (dateRangePicked != null) {
      setState(() {
        _dateTimeRange = DateTimeRange(
            start: dateRangePicked.start.copyWith(
                hour: _dateTimeRange.start.hour,
                minute: _dateTimeRange.start.minute),
            end: dateRangePicked.end.copyWith(
                hour: _dateTimeRange.end.hour,
                minute: _dateTimeRange.end.minute));
      });
    }
  }

  _selectTimeRange() async {
    DateTime start = await _selectStartTime();
    DateTime end = await _selectEndTime(start);
    setState(() {
      _dateTimeRange = DateTimeRange(start: start, end: end);
    });
  }

  Future<DateTime> _selectStartTime() async {
    DateTime startDate = _dateTimeRange.start;
    final TimeOfDay? timeOfDayPicked = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(_dateTimeRange.start));
    if (timeOfDayPicked != null) {
      startDate = _dateTimeRange.start
          .copyWith(hour: timeOfDayPicked.hour, minute: timeOfDayPicked.minute);
    }
    return startDate;
  }

  Future<DateTime> _selectEndTime(DateTime start) async {
    DateTime endDate = _dateTimeRange.end;
    final TimeOfDay? timeOfDayPicked = await showTimePicker(
        context: context, initialTime: TimeOfDay.fromDateTime(endDate));
    if (timeOfDayPicked != null) {
      endDate = _dateTimeRange.end
          .copyWith(hour: timeOfDayPicked.hour, minute: timeOfDayPicked.minute);
    }
    return endDate;
  }

  String? _validateTitle(String? title) {
    final eventViewModel = context.read<EventViewModel>();
    if (title == null || title.isEmpty) {
      return 'Please enter a title.';
    } else if (eventViewModel.eventTitles.contains(title)) {
      return 'Event $title already exists.';
    }
    return null;
  }

  String? _validateDescription(String? title) {
    if (title == null || title.isEmpty) {
      return 'Please enter a description.';
    }
    return null;
  }

  _submit() {
    if (_formKey.currentState!.validate()) {
      final event = Event(
          _titleController.text, _descriptionController.text, _dateTimeRange);
      final eventViewModel = context.read<EventViewModel>();
      eventViewModel.addEvent(event);
      _formKey.currentState!.reset();
      _dateTimeRange =
          DateTimeRange(start: DateTime.now(), end: DateTime.now());
      if (context.canPop()) context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Form(
            key: _formKey,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Title'),
                    controller: _titleController,
                    validator: _validateTitle,
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Description'),
                    controller: _descriptionController,
                  ),
                  // const DateSelector(),
                  Text(
                    '${_dateDisplay(_dateTimeRange.start)} - ${_dateDisplay(_dateTimeRange.end)}',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  Text(
                    '${_timeDisplay(_dateTimeRange.start)} - ${_timeDisplay(_dateTimeRange.end)}',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    OutlinedButton(
                        onPressed: () => _selectDateRange(),
                        child: const Text('Edit Date Range')),
                    OutlinedButton(
                        onPressed: _selectTimeRange,
                        child: const Text('Edit Time Range'))
                  ]),
                  ElevatedButton(
                      onPressed: _submit, child: const Text("Add Event")),
                ]))
      ],
    );
  }
}
