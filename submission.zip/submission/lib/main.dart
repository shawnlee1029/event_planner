import 'package:event_planner/event_details_page.dart';
import 'package:flutter/material.dart';
import 'package:event_planner/event_view_model.dart';
import 'package:event_planner/event_viewer.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'event_form_button.dart';
import 'event_form_page.dart';

void main() {
  runApp(const MyApp());
}

//TODO EventDetailsView next event
//TODO EventDetailsView previous event
//TODO EventDetailsView EventViewer
//TODO EventDetailsView previous view

//TODO add time selection

final router = GoRouter(initialLocation: '/home', routes: [
  GoRoute(
      path: '/home', name: 'home', builder: (context, _) => const HomePage()),
  GoRoute(
      path: '/form',
      name: 'form',
      builder: (context, _) => const EventFormPage()),
  GoRoute(
      path: '/event/:eventId',
      name:'event',
      builder: (context, state) =>
          EventDetailsPage(index: int.parse(state.pathParameters['eventId']!)))
]);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => EventViewModel(),
      child: MaterialApp.router(
        title: 'Event Planner',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.teal,
        ),
        routerConfig: router,
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isFilteringPastEvents = false;
  bool allowNavigation = true;

  _onToggleFilterPastEvents() {
    final eventViewModel = context.read<EventViewModel>();
    _isFilteringPastEvents = !_isFilteringPastEvents;
    setState(() {
      eventViewModel.filterPastEvents = _isFilteringPastEvents;
      eventViewModel.toggleFilter();
    });
    print('filter: ${eventViewModel.filterPastEvents}');

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          actions: [
            InkWell(
                onTap: _onToggleFilterPastEvents,
                child: _isFilteringPastEvents
                    ? const Icon(Icons.filter_alt)
                    : const Icon(Icons.filter_alt_off))
          ],
        ),
        body: const EventViewer(),
        floatingActionButton: const EventFormButton());
  }
}
