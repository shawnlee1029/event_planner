import 'package:flutter/material.dart';

class Event {
  final String title;
  final String description;
  // final DateTime start;
  // final DateTime end;
  DateTimeRange dateRange;
  Event(this.title, this.description, this.dateRange);

  @override
  String toString() {
    return '$title:\t$description\n${monthDayYear(dateRange.start)} - ${monthDayYear(dateRange.end)}';
  }

  String monthDayYear(DateTime date) {
    String month = date.month.toString();
    String day = date.day.toString();
    String year = date.year.toString();
    return '$month/$day/$year';
  }
}
