import 'package:flutter/material.dart';
import 'event.dart';
import 'package:intl/intl.dart';
import 'package:event_planner/event_describer.dart';
class EventViewModel extends ChangeNotifier {
  final List<Event> _events = [];
  bool filterPastEvents = false;

  void addEvent(Event event) {
    print('adding $event to $_events');
    _events.add(event);
    _sort();
    notifyListeners();
  }
  void toggleFilter(){
    filterPastEvents = !filterPastEvents;
    notifyListeners();
  }
  void removeEvent(int index) {
    print('removing $index from $_events');
    _events.removeAt(index);
    notifyListeners();
  }

  void editEventDateRange(DateTimeRange dateTimeRange, int index) {
    if (filterPastEvents) {
      _getPastEvents()[index].dateRange = dateTimeRange;
    } else {
      _events[index].dateRange = dateTimeRange;
    }
    notifyListeners();
  }

  void _sort() {
    _events.sort((a, b) => a.dateRange.start.compareTo(b.dateRange.start));
  }

  List<Event> _getPastEvents() {
    DateTime dt = DateTime.now();
    return _events
        .where((event) =>
            !event.dateRange.end.isBefore(DateTime(dt.year, dt.month, dt.day)))
        .toList();
  }
  String startDisplay({ required int index, bool date = true, bool time = false}) {
    String display = '';
    DateTime dateTime = getStart(index);
    if(date) {
      display += DateFormat().add_yMd().format(dateTime);
    }
    if(time) {
      display += DateFormat().add_jm().format(dateTime);
    }
    return display;
  }
  String endDisplay({ required int index, bool date = true, bool time = false}) {
    String display = '';
    DateTime dateTime = getEnd(index);
    if(date) {
      display += DateFormat().add_yMd().format(dateTime);
    }
    if(time) {
      display += DateFormat().add_jm().format(dateTime);
    }
    return display;
  }
  String getTitle(index) => _getEvent(index).title;
  DateTimeRange getDateTimeRange(index) => _getEvent(index).dateRange;
  String getDescription(index) => _getEvent(index).description;
  DateTime getStart(index) => _getEvent(index).dateRange.start;
  DateTime getEnd(index) => _getEvent(index).dateRange.end;




  String getStartString(index) => filterPastEvents
      ? DateFormat.yMd().add_jm().format(_getPastEvents()[index].dateRange.start)
      : DateFormat.yMd().add_jm().format(_events[index].dateRange.start);

  String getEndString(index) => filterPastEvents
      ? DateFormat.yMd().add_jm().format(_getPastEvents()[index].dateRange.end)
      : DateFormat.yMd().add_jm().format(_events[index].dateRange.end);

  String getSubtitle(index) => 'subtitle';

  int get eventCount =>
      filterPastEvents ? _getPastEvents().length : _events.length;

  List<String> get eventTitles => filterPastEvents
      ? _getPastEvents().map((event) => event.title).toList()
      : _events.map((event) => event.title).toList();

  List<String> get eventDescriptions => filterPastEvents
      ? _getPastEvents().map((event) => event.description).toList()
      : _events.map((event) => event.description).toList();

  List<String> get eventDurations => filterPastEvents
      ? _getPastEvents()
          .map((event) => '${DateFormat.yMd().add_jm().format(event.dateRange.start)}'
              ' - ${DateFormat.yMd().add_jm().format(event.dateRange.end)}')
          .toList()
      : _events
          .map((event) => '${DateFormat.yMd().add_jm().format(event.dateRange.start)}'
              ' - ${DateFormat.yMd().add_jm().format(event.dateRange.end)}')
          .toList();

  List<DateTimeRange> get eventDateTimeRanges => filterPastEvents
      ? _getPastEvents().map((event) => event.dateRange).toList()
      : _events.map((event) => event.dateRange).toList();

  Event _getEvent(index) => filterPastEvents ? _getPastEvents()[index] :_events[index];
}

