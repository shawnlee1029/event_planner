import 'package:intl/intl.dart';

import 'event.dart';

extension EventDescriber on Event{
  }