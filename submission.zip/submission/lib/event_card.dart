import 'package:event_planner/date_selector.dart';
import 'package:event_planner/event_view_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'event_details_view_button.dart';

class EventCard extends StatelessWidget {
  final int index;
  final List<String> titles;
  final List<String> descriptions;
  final List<String> durations;

  const EventCard(
      {Key? key,
      required this.titles,
      required this.descriptions,
      required this.durations,
      required this.index})
      : super(key: key);

  _onDelete(int index, EventViewModel eventViewModel) {
    print('delete $index');
    eventViewModel.removeEvent(index);
  }

  @override
  Widget build(BuildContext context) {
    final eventViewModel = context.read<EventViewModel>();

    return Card(
        child: ListTile(
      title: Text(titles[index]),
      subtitle: Text(
          '${descriptions[index]}\n${durations[index]}'),
      trailing: Wrap(
        spacing: 5,
        children: [
          // Text('$index'),
          EventDetailsViewButton(index: index),
          //DateSelector(index: index),
          // ElevatedButton(
          //   onPressed: () {},
          //   child: const Icon(Icons.calendar_month),
          // ),
          ElevatedButton(
            onPressed: () {
              _onDelete(index, eventViewModel);
            },
            child: const Icon(Icons.delete_sharp),
          ),
        ],
      ),
    ));
  }
}
