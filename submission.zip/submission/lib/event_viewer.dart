import 'package:event_planner/event_card.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'event_details_view_button.dart';
import 'event_view_model.dart';

class EventViewer extends StatelessWidget {
  const EventViewer({super.key});

  _onEdit(int index, DateTimeRange dateTimeRange, BuildContext context,
      EventViewModel eventViewModel) async {
    final DateTimeRange? dateRangePicked = await showDateRangePicker(
        context: context,
        initialDateRange: dateTimeRange,
        firstDate: DateTime(2023),
        lastDate: DateTime(2123));
    if (dateRangePicked != null) {
      eventViewModel.editEventDateRange(dateRangePicked, index);
    }
  }

  _onDelete(int index, EventViewModel eventViewModel) {
    print('delete $index');
    eventViewModel.removeEvent(index);
  }

  @override
  Widget build(BuildContext context) {
    final eventViewModel = context.read<EventViewModel>();
    return AnimatedBuilder(
        animation: eventViewModel,
        builder: (context, _) {
          final titles = eventViewModel.eventTitles;
          final descriptions = eventViewModel.eventDescriptions;
          final durations = eventViewModel.eventDurations;
          final dateRanges = eventViewModel.eventDateTimeRanges;
          return ListView.builder(
              itemCount: eventViewModel.eventCount,
              itemBuilder: (context, index) => EventCard(
                  titles: titles,
                  descriptions: descriptions,
                  durations: durations,
                  index: index));
        });
  }
}
